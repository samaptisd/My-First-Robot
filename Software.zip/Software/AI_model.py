# """
# Step 2:
# Text Generation using Gemini API
# generate API key from: https://ai.google.dev/gemini-api/docs/api-key
# """

# import google.generativeai as genai
# import grpc

# # Configure the Gemini API with your API key.
# genai.configure(api_key="AIzaSyBMNvZCzM87667Mm4eFvAr3QWfBFFr6XHc")


# def gemini_api(text):
#     # Initialize a genAI model
#     model = genai.GenerativeModel(model_name="gemini-1.5-flash-latest")
#     # generate a response based on the input text.
#     response = model.generate_content(text)

#     print(response.text)


# # -------------MAIN----------------

# text = "Hi, be my personal AI robot. explain to me what an api is briefly?"
# gemini_api(text)

# grpc._channel._Rendezvous.__del__ = lambda self: None
# # grpc._network_state._reset_network_state()



import os
import google.generativeai as genai
import grpc

# Load API Key from environment variable
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise ValueError("❌ ERROR: GEMINI_API_KEY environment variable is not set.")

# Configure Gemini API
genai.configure(api_key=API_KEY)

def gemini_api(text):
    """ Generate a response using Google's Gemini API """
    try:
        model = genai.GenerativeModel(model_name="gemini-1.5-flash-latest")
        response = model.generate_content(text)
        print(response.text)
    except grpc.RpcError as e:
        print(f"⚠️ gRPC Error: {e}")
    finally:
        # Properly close gRPC to avoid shutdown timeout issues
        grpc._channel._Rendezvous.__del__ = lambda self: None
        print("✅ gRPC connection closed successfully.")

# -------------MAIN----------------
if __name__ == "__main__":
    text = "Hi, be my personal AI robot. Explain to me what an API is briefly?"
    gemini_api(text)

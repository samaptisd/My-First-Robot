"""
Step 3: Text to Speech model
"""
import io
import pygame
from openai import OpenAI

client = OpenAI(api_key="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")

# Function to play audio using pygame
def play_audio(audio_bytes):
    pygame.mixer.init()
    pygame.mixer.music.load(io.BytesIO(audio_bytes))
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(10)

def openai_text_to_speech(text):
    # Generate speech
    response = client.audio.speech.create(
        model="tts-1",
        voice="alloy",
        input= text
    )
    # Extract audio content from the response
    audio_content = response.read()  # Read the binary content from the response
    return audio_content

# Play the audio
text = "Hi, I'm OpenAI's text to speech model"
response = openai_text_to_speech(text)
play_audio(response)


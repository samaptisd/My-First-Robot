import serial

try:
    ser = serial.Serial("COM4", 9600, timeout=1)
    print("Connected to COM4!")
    ser.close()
except Exception as e:
    print("Failed to connect to COM4:", e)
